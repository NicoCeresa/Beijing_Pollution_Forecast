How To Run:

Just run the script 
```
python3 project_4_script.py 
```
in your terminal.